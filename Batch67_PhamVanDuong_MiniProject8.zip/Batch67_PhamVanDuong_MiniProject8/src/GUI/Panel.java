package GUI;

import javax.swing.*;
import java.awt.*;

public class Panel extends JPanel {
    public int[] X;
    public int min;
    public int max;
    public int minDiff;
    public Color color = new Color(255, 0, 255, 255);

    public Panel() {
        X = new int[1];
        setSize(800, 600);
        setBackground(new Color(0, 0, 0, 255));
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.green);
        g.drawRect(0, 300, 800, 2);
        g.drawRect(100, 0, 2, 600);
        g.setColor(color);
        /*
        for (int i = 0; i < X.length; i++) {
            g.fillRect(100+5*i,0,2,X[i]*20);
        }

         */
        for (int i = 0; i < X.length; i++) {
            if (X[i] == min) {
                g.setColor(new Color(112, 212, 121));
            } else if (X[i] == max) {
                g.setColor(new Color(80, 000, 200));
            } else {
                g.setColor(color);
            }
            g.fillRect(100 + 8 * i, 600 - (X[i] * 28 + 300), 3, X[i] * 28);
        }
        g.setColor(Color.BLUE);
        g.fillRect(100, 600 - (min * 28 + 300), 800, 1);
        g.setColor(Color.WHITE);
        g.fillRect(100, 600 - (max * 28 + 300), 800, 1);
    }
}
