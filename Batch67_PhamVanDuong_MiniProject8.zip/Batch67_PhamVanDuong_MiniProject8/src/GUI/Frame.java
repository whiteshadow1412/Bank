package GUI;

import javax.swing.*;
import java.awt.*;

public class Frame extends JFrame {
    public static int sleep = 0;
    public Panel panel = new Panel();

    public Frame() throws HeadlessException {
        setSize(800, 600);
        setVisible(true);
        setBackground(new Color(0, 0, 0, 255));
        add(panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
