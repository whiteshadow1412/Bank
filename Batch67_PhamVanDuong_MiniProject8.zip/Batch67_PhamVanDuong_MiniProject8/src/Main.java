import FromTeacher.BCASolver;
import GUI.Frame;

public class Main {
    public static void main(String[] args) {
        if (args.length >= 2) {
            Frame.sleep = Integer.parseInt(args[1]);
        }
        Frame frame = new Frame();
        BCASolver bcaSolver = new BCASolver();
        bcaSolver.loadData(args[0]);
        bcaSolver.setPanel(frame.panel);
        bcaSolver.solve();
    }
}