package FromTeacher;

import GUI.Frame;
import GUI.Panel;
import java.io.File;
import java.util.Arrays;
import java.util.Scanner;

public class BCAModel extends Thread{
    Panel panel;
    private int[] X;
    private int[] X_best;
    private int f_best;
    private int maxLoad;
    private int n;
    private int m;
    private boolean[][] conflict;
    private boolean[][] teach;

    public boolean check(int k) {
        try {
            sleep(Frame.sleep);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        for (int i = 1; i <= k; i++) {
            if (!teach[X[i]][i]) {
                panel.X=X;
                //panel.color=Color.red;
                panel.repaint();
                return false;

            }
            for (int j = i; j <= k; j++) {
                if (X[i] == X[j] && conflict[i][j]) {
                    panel.X=X;
                    //panel.color=Color.red;
                    panel.repaint();
                    return false;
                }
            }
        }
        panel.X=X;
        //panel.color=Color.green;
        panel.repaint();
        return true;
    }

    public void tryValue(int k) {

        for (int v = 1; v <= n; v++) {
            X[k] = v;
            if (!check(k)) {
                continue;
            }
            if (k == m) {
                int[] count = new int[n + 1];
                for (int i = 1; i <= m; i++) {
                    count[X[i]]++;
                }
                int[] count2 = new int[n + 1];
                System.arraycopy(count, 0, count2, 0 , count2.length);
                Arrays.sort(count);
                if (count[n] - count[1] < f_best) {
                    f_best = count[n] - count[1];
                    maxLoad = count[n];
                    System.arraycopy(X, 0, X_best, 0, X.length);

                }
                for(int i=1; i<=n; i++){
                    if(count2[i]==count[1]){
                        panel.min=i;
                        panel.repaint();
                        break;
                    }
                }
                for(int i=1; i<=n; i++){
                    if(count2[i]==count[n]){
                        panel.max=i;
                        panel.repaint();
                        break;
                    }
                }
            } else {
                tryValue(k + 1);
            }
        }

    }

    public void solve() {
        tryValue(1);
        System.out.println("Result is: ");
        printSolution();
    }

    public void printSolution() {
        if(maxLoad==0){
            System.out.println("Can't Solve");
            return;
        }
        for (int i = 1; i <= m; i++) {
            System.out.print(X_best[i] + " + ");
        }
        System.out.println("../");
        System.out.println("Min different is: "+ f_best);
        System.out.println("Max load: "+ maxLoad);
        panel.X=X_best;
        panel.repaint();
    }

    public void loadData(String file) {
        try {
            Scanner scanner = new Scanner(new File(file));
            n = scanner.nextInt(); //number of teacher
            m = scanner.nextInt();
            teach = new boolean[n + 1][m + 1];
            conflict = new boolean[m + 1][m + 1];
            X = new int[m + 1];
            X_best = new int[m + 1];
            f_best = 999;
            maxLoad = 0;
            for (int i = 1; i <= n; i++) {
                int courseNum = scanner.nextInt();
                for (int j = 1; j <= courseNum; j++) {
                    int courseId = scanner.nextInt();
                    teach[i][courseId] = true;
                }
            }
            int k = scanner.nextInt();
            for (int i = 0; i < k; i++) {
                int courseId = scanner.nextInt();
                int conflictId = scanner.nextInt();
                conflict[courseId][conflictId] = true;
                conflict[conflictId][courseId] = true;
            }
            System.out.println(scanner.nextLine());
            System.out.println(scanner.nextLine());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
