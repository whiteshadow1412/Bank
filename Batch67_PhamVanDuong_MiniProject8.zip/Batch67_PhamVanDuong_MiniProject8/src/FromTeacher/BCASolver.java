package FromTeacher;

import GUI.Panel;

import java.io.File;

public class BCASolver {
    private final BCAModel model = new BCAModel();

    public void loadData(String file) {
        model.loadData(file);
    }

    public void solve() {
        model.solve();
    }

    public void setPanel(Panel panel) {
        model.panel = panel;
    }
}
